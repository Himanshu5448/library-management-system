#!C:\Users\singh\OneDrive\Desktop\x\Django-librarymanagement\env\Scripts\python.exe
from django.core import management

if __name__ == "__main__":
    management.execute_from_command_line()
